import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ClockView()
                .tabItem { Label("时钟", systemImage: "clock") }
            StopwatchView()
                .tabItem { Label("秒表", systemImage: "stopwatch") }
            CalculatorView()
                .tabItem { Label("计算器", systemImage: "plus.forwardslash.minus") }
            AboutView()
                .tabItem { Label("关于", systemImage: "info.circle") }
        }
        .tint(.cyan)
    }
}

struct ClockView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.055, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 18) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 34))
                        .foregroundStyle(.cyan)
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        VStack(spacing: 8) {
                            Text(context.date.formatted(date: .omitted, time: .shortened))
                                .font(.system(size: 64, weight: .light, design: .rounded))
                                .monospacedDigit()
                                .minimumScaleFactor(0.5)
                                .lineLimit(1)
                            Text(context.date.formatted(
                                .dateTime.year().month(.wide).day().weekday(.wide)
                                    .locale(Locale(identifier: "zh_CN"))
                            ))
                            .font(.headline)
                            .foregroundStyle(.secondary)
                        }
                    }
                    Text("把每一刻，都安排得刚刚好。")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.55))
                        .padding(.top, 18)
                }
                .padding()
            }
            .navigationTitle("MiniTools")
        }
    }
}

struct StopwatchView: View {
    @State private var isRunning = false
    @State private var startDate: Date?
    @State private var accumulated: TimeInterval = 0

    private func elapsed(at date: Date) -> TimeInterval {
        accumulated + (isRunning ? date.timeIntervalSince(startDate ?? date) : 0)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.055, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 34) {
                    TimelineView(.periodic(from: .now, by: 0.03)) { context in
                        Text(elapsed(at: context.date).formatted(.number.precision(.fractionLength(2))))
                            .font(.system(size: 58, weight: .light, design: .rounded))
                            .monospacedDigit()
                            .minimumScaleFactor(0.5)
                            .lineLimit(1)
                    }
                    HStack(spacing: 18) {
                        Button {
                            if isRunning {
                                accumulated = elapsed(at: .now)
                                isRunning = false
                                startDate = nil
                            } else {
                                startDate = .now
                                isRunning = true
                            }
                        } label: {
                            Label(isRunning ? "暂停" : "开始", systemImage: isRunning ? "pause.fill" : "play.fill")
                                .frame(width: 130, height: 52)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(isRunning ? .orange : .cyan)

                        Button {
                            accumulated = 0
                            startDate = isRunning ? .now : nil
                        } label: {
                            Label("重置", systemImage: "arrow.counterclockwise")
                                .frame(width: 110, height: 52)
                        }
                        .buttonStyle(.bordered)
                        .disabled(accumulated == 0 && !isRunning)
                    }
                }
                .padding()
            }
            .navigationTitle("秒表")
        }
    }
}

struct CalculatorView: View {
    @State private var display = "0"
    @State private var storedValue: Double?
    @State private var pendingOperation: String?
    @State private var startsNewNumber = true

    private let rows = [
        ["C", "±", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "−"],
        ["1", "2", "3", "+"],
        ["0", ".", "="]
    ]

    private func number(_ value: String) {
        if startsNewNumber {
            display = value == "." ? "0." : value
            startsNewNumber = false
        } else if value == "." {
            if !display.contains(".") { display += "." }
        } else {
            display = display == "0" ? value : display + value
        }
    }

    private func operate(_ operation: String) {
        guard let current = Double(display) else { return }
        if operation == "C" {
            display = "0"; storedValue = nil; pendingOperation = nil; startsNewNumber = true
            return
        }
        if operation == "±" {
            display = String(-current); return
        }
        if operation == "%" {
            display = String(current / 100); return
        }
        if operation == "=" {
            guard let first = storedValue, let pending = pendingOperation else { return }
            var result = current
            switch pending {
            case "+": result = first + current
            case "−": result = first - current
            case "×": result = first * current
            case "÷": result = current == 0 ? 0 : first / current
            default: break
            }
            display = result.isFinite ? String(result) : "错误"
            storedValue = nil; pendingOperation = nil; startsNewNumber = true
            return
        }
        storedValue = current
        pendingOperation = operation
        startsNewNumber = true
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.055, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 12) {
                    Spacer()
                    Text(display)
                        .font(.system(size: 48, weight: .light, design: .rounded))
                        .monospacedDigit()
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .lineLimit(1)
                        .minimumScaleFactor(0.4)
                        .padding(.horizontal, 8)
                    ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                        HStack(spacing: 12) {
                            ForEach(row, id: \.self) { item in
                                Button {
                                    if ["C", "±", "%", "÷", "×", "−", "+", "="].contains(item) {
                                        operate(item)
                                    } else {
                                        number(item)
                                    }
                                } label: {
                                    Text(item)
                                        .font(.title2.weight(.medium))
                                        .frame(maxWidth: .infinity, minHeight: 62)
                                        .background(buttonColor(item), in: RoundedRectangle(cornerRadius: 18))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("计算器")
        }
    }

    private func buttonColor(_ item: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(item) { return .cyan.opacity(0.28) }
        if ["C", "±", "%"].contains(item) { return .white.opacity(0.13) }
        return .white.opacity(0.07)
    }
}

struct AboutView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.055, blue: 0.09).ignoresSafeArea()
                VStack(spacing: 16) {
                    Image(systemName: "square.grid.2x2.fill")
                        .font(.system(size: 54))
                        .foregroundStyle(.cyan)
                    Text("MiniTools")
                        .font(.largeTitle.bold())
                    Text("一个用于测试 iOS 云端构建流程的小工具箱。")
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    Text("Version 1.0 · SwiftUI")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.45))
                }
                .padding(30)
            }
            .navigationTitle("关于")
        }
    }
}
