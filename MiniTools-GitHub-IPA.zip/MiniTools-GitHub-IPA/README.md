# MiniTools — GitHub Actions IPA 测试项目

这是一个 SwiftUI 小工具箱，包含时钟、秒表、计算器和关于页面。项目的主要目的，是验证 GitHub Actions 的 macOS runner 能否编译并导出 iOS IPA。

## 重要说明

- 需要有效的 Apple 签名证书（`.p12`）和匹配的 Development provisioning profile（`.mobileprovision`）。
- Development 描述文件必须包含准备安装 IPA 的设备 UDID。
- 本仓库的 workflow 通过 GitHub Actions secrets 读取证书和描述文件，不要把证书、密码或描述文件提交到 GitHub 仓库。
- 这份工程是一个最小可用的起点；首次运行若遇到 Xcode 版本、证书类型或描述文件名称不匹配，需要按日志调整签名配置。

## 1. 创建 GitHub 仓库并上传

1. 登录 GitHub，创建一个空仓库，例如 `MiniTools`。
2. 解压本 ZIP。
3. 把解压后的所有文件和隐藏目录 `.github` 一起上传到仓库根目录。
4. 确认仓库中能看到 `MiniTools.xcodeproj`、`MiniTools` 文件夹和 `.github/workflows/build-ipa.yml`。

## 2. 设置签名材料

在 GitHub 仓库进入 **Settings → Secrets and variables → Actions**。

### Repository secrets

添加以下 4 个 Secrets：

| 名称 | 内容 |
|---|---|
| `IOS_CERTIFICATE_BASE64` | `.p12` 文件的 Base64 文本 |
| `IOS_CERTIFICATE_PASSWORD` | 导出 `.p12` 时设置的密码 |
| `IOS_PROVISIONING_PROFILE_BASE64` | `.mobileprovision` 文件的 Base64 文本 |
| `IOS_TEAM_ID` | Apple Developer Team ID |

### Repository variable

在 **Variables** 中添加：

| 名称 | 内容 |
|---|---|
| `IOS_BUNDLE_ID` | 例如 `com.yourname.MiniTools`，必须与描述文件中的 App ID 一致 |

Base64 可以在本地终端生成：

```bash
base64 -i signing.p12 | tr -d '\n'
base64 -i profile.mobileprovision | tr -d '\n'
```

Windows PowerShell 可用：

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("signing.p12"))
[Convert]::ToBase64String([IO.File]::ReadAllBytes("profile.mobileprovision"))
```

把输出内容粘贴到对应 Secret。不要把 Base64 内容发给别人。

## 3. 运行 GitHub Actions

1. 打开仓库的 **Actions**。
2. 选择 **Build MiniTools IPA**。
3. 点击 **Run workflow**。
4. 等待任务完成，打开成功的运行记录。
5. 在页面底部的 **Artifacts** 下载 `MiniTools-IPA`。

下载后解压 Artifact，即可得到 `MiniTools.ipa`。

## 4. 安装说明

Development IPA 只能安装到 provisioning profile 已登记的设备上。可使用你信任的侧载工具安装；若设备不在描述文件中，安装会失败。证书过期或描述文件过期也需要重新签名。

## 常见失败原因

- `No profiles for ... were found`：Bundle ID 与描述文件不匹配，或 profile 没有正确安装。
- `Signing certificate ... not found`：P12 不正确，或证书类型与 workflow 使用的身份不匹配。
- `requires a provisioning profile`：没有匹配的 Development profile。
- `No such file or directory: Xcode_16.2`：runner 上 Xcode 路径有变化；workflow 中的 `xcode-select` 会尝试回退到默认 Xcode。
- `ExportArchive` 报 provisioning profile 错误：确认 profile 的 App ID、Team ID、证书和设备 UDID 都匹配。

## 项目结构

```text
MiniTools/
├── MiniTools.xcodeproj/
├── MiniTools/
│   ├── MiniToolsApp.swift
│   ├── ContentView.swift
│   └── Info.plist
└── .github/
    └── workflows/
        └── build-ipa.yml
```
